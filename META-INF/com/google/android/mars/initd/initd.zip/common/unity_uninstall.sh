# Patch boot img if not using root solution that supports boot scripts
$MAGISK || { ui_print "   To uninstall this mod, dirty flash your rom"; sleep 3; ui_print " "; }
